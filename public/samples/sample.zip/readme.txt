Every entry has a local header before its data and a central
directory record at the end of the archive.
